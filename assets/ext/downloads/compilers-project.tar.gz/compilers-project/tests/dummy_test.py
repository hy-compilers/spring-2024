
# This test file only exists so you can check that the test runner works.
# You can delete it after writing your first real test.
def test_dummy() -> None:
    assert 1 + 1 == 2
